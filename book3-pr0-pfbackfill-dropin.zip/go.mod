module github.com/nicholaskarlson/proof-first-backfills-gcp

go 1.22

require gopkg.in/yaml.v3 v3.0.1
